package main;

public class main {

    public static void main(String[] args){
        
        Configuracao configuracao = new Configuracao();
        configuracao.iniciarPrograma();
        configuracao.mostraResultados();
       
    }

}
